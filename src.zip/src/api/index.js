export const GET_BET_SLIP = "/api/sport/bet_slip";
export const GET_TODAY_SPORT_BY_ORDER = "/api/sport/sport_by_order";
export const UPDATE_SPORT_OPEN = '/api/sport/update-sport-open';
export const GET_LEAGUE_BY_DATE = '/api/sport/get-league-by-date';
export const BET_RESUMPTION = '/api/sport/bet-resumption';
export const BET_EVENT = '/api/sport/bet-event';