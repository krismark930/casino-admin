<template>
  <Form />
  <Table />
</template>
<script>
import Form from '@/views/lottery/alwaysColors/resultsManagement/taiwanConstantColor/form.vue'
import Table from '@/views/lottery/alwaysColors/resultsManagement/taiwanConstantColor/table.vue'
export default {
  formData: {},
  components: {
    Form,
    Table,
  },
}
</script>

<style lang="scss" scoped></style>
