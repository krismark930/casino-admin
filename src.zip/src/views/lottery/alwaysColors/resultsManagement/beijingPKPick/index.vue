<template>
  <Form />
  <Table />
</template>
<script>
import Form from '@/views/lottery/alwaysColors/resultsManagement/beijingPKPick/form.vue'
import Table from '@/views/lottery/alwaysColors/resultsManagement/beijingPKPick/table.vue'
export default {
  formData: {},
  components: {
    Form,
    Table,
  },
}
</script>

<style lang="scss" scoped></style>
