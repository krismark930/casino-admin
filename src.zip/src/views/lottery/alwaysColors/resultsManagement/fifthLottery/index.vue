<template>
  <Form />
  <Table />
</template>
<script>
import Form from '@/views/lottery/alwaysColors/resultsManagement/fifthLottery/form.vue'
import Table from '@/views/lottery/alwaysColors/resultsManagement/fifthLottery/table.vue'
export default {
  formData: {},
  components: {
    Form,
    Table,
  },
}
</script>

<style lang="scss" scoped></style>
