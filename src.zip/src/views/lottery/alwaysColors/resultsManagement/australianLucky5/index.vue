<template>
  <Form />
  <Table />
</template>
<script>
import Form from '@/views/lottery/alwaysColors/resultsManagement/australianLucky5/form.vue'
import Table from '@/views/lottery/alwaysColors/resultsManagement/australianLucky5/table.vue'
export default {
  formData: {},
  components: {
    Form,
    Table,
  },
}
</script>

<style lang="scss" scoped></style>
