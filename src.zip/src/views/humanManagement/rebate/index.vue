<template>
  <div
    style="border: 1px solid #eee; padding: 0.75rem; margin-top: 0.75rem; text-align: center; margin: 1rem;"
  >
    <h3>一键反水</h3>
    <el-tabs type="border-card">
      <el-tab-pane label="真人返水"><LiveRebate /></el-tab-pane>
      <el-tab-pane label="电子返水"><ERebate /></el-tab-pane>
      <el-tab-pane label="棋牌返水"><ChessRebate /></el-tab-pane>
      <el-tab-pane label="捕鱼返水"><FishingRebate /></el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import LiveRebate from '@/views/humanManagement/rebate/liveRebate.vue'
import ERebate from '@/views/humanManagement/rebate/ERebate.vue'
import FishingRebate from '@/views/humanManagement/rebate/fishingRebate.vue'
import ChessRebate from '@/views/humanManagement/rebate/chessRebate.vue'

export default {
  data() {
    return {}
  },
  methods: {},
  components: {
    LiveRebate,
    ERebate,
    FishingRebate,
    ChessRebate,
  },
}
</script>
