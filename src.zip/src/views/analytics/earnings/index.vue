<template>This is earning page</template>
